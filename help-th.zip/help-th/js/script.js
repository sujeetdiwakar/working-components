(function( $, window, document, undefined ) {

	'use strict';

	$(
		function() {

			$( '#nav' ).mmenu(
				{
					scrollBugFix: true,
					offCanvas: {
						position: 'left'
					}
				}, {
					clone: true
				}
			);

			$( '.js-content-slider' ).slick( {
				dots: true,
				infinite: true,
				arrows: false,
				rows: 0,
				autoplay: true,
				autoplaySpeed: 4000,
			} );

			$( '.js-carousel-product' ).slick( {
				rows: 0,
				speed: 300,
				dots: false,
				slidesToShow: 4,
				infinite: false,
				slidesToScroll: 1,
				responsive: [
					{
						breakpoint: 1170,
						settings: {
							slidesToShow: 3,
							slidesToScroll: 3
						}
					},
					{
						breakpoint: 600,
						settings: {
							slidesToShow: 2,
							slidesToScroll: 2
						}
					},
					{
						breakpoint: 480,
						settings: {
							slidesToShow: 1,
							slidesToScroll: 1
						}
					}
					// You can unslick at a given breakpoint now by adding:
					// settings: "unslick"
					// instead of a settings object
				]
			} );

			$( 'table.wishlist_table tr th.product-name' ).attr( 'colspan', '3' );

			$( window ).scroll( function() {
				if ( $( window ).scrollTop() >= 330 ) {
					$( '.header' ).addClass( 'header--fixed' );
				} else {
					$( '.header' ).removeClass( 'header--fixed' );
				}
			} );
		}
	);

})( jQuery, window, document );
