<?php
/**
 * The template for displaying the footer
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      1.0
 * @version    1.0
 */
?>
<footer class="footer">
	<div class="footer__widgets container">
		<?php if ( is_active_sidebar( 'footer_1' ) ): ?>
			<aside>
				<?php dynamic_sidebar( 'footer_1' ); ?>
			</aside>
		<?php endif;

		if ( is_active_sidebar( 'footer_2' ) ): ?>
			<aside>
				<?php dynamic_sidebar( 'footer_2' ); ?>
			</aside>
		<?php endif;

		if ( is_active_sidebar( 'footer_3' ) ): ?>
			<aside>
				<?php dynamic_sidebar( 'footer_3' ); ?>
			</aside>
		<?php endif;

		if ( is_active_sidebar( 'footer_4' ) ): ?>
			<aside>
				<?php dynamic_sidebar( 'footer_4' ); ?>
			</aside>
		<?php endif; ?>
	</div>

	<div class="footer__copyright container">
		<p>© <?php echo date( 'Y - ' ); ?>
			<a href="<?php echo get_option( 'home' ); ?>/"><?php bloginfo( 'name' ); ?></a>
			| <?php _e( 'My Theme: ' ); ?>
			<a href="#" target="_blank"><?php _e( 'My Theme' ); ?></a>
		</p>

		<?php if ( ( $mode = get_field( 'payment_mode', 'option' ) ) && ! empty( $mode ) ): ?>
			<figure>
				<?php echo wp_get_attachment_image( $mode['id'], 'large' ); ?>
			</figure>
		<?php endif; ?>
	</div>
</footer>
</div>

<?php wp_footer(); ?>
</body>
</html>