<?php
/**
 * The template used for displaying blog content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
?>
<article class="content<?php if ( is_active_sidebar( 'right_sidebar' ) ): ?> content--sidebar<?php endif; ?>">
	<div class="content__article">
		<h1><?php echo get_the_title( get_option( 'page_for_posts' ) ); ?></h1>
		<?php if ( have_posts() ) : ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'template-parts/loop', 'post' ); ?>
			<?php endwhile; ?>
			<?php get_template_part( 'template-parts/content', 'pagination' ); ?>
		<?php else : ?>
			<h2>Not Found</h2>
			<p>Sorry, but you are looking for something that isn't here.</p>
		<?php endif; ?>
	</div>
</article>