<?php
/**
 * The template used for displaying pagination
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
?>
<div class="content__article__nav">
	<?php echo paginate_links( [ 'prev_text' => '<', 'next_text' => '>' ] ); ?>
</div>
