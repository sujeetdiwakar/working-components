<?php
/**
 * The template used for displaying product USP info
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */

if ( have_rows( 'usps_list' ) ): ?>
	<div class="info">
		<ul>
			<?php while ( have_rows( 'usps_list' ) ) : the_row(); ?>
				<li>
					<?php the_sub_field( 'icon' ); ?>
					<?php the_sub_field( 'title' ); ?>
				</li>
			<?php endwhile; ?>
		</ul>
	</div>

<?php elseif ( have_rows( 'usps_list', 'option' ) ) : ?>

	<div class="info">
		<ul>
			<?php while ( have_rows( 'usps_list', 'option' ) ) : the_row(); ?>
				<li>
					<?php the_sub_field( 'icon' ); ?>
					<?php the_sub_field( 'title' ); ?>
				</li>
			<?php endwhile; ?>
		</ul>
	</div>
<?php endif; ?>