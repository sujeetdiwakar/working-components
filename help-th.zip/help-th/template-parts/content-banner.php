<?php
/**
 * The template used for displaying page banner
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
?>
<div class="banner">
	<div class="container">
		<img src="<?php echo get_template_directory_uri(); ?>/images/banner.jpg">
	</div>
</div>