<?php $number_of_product_display = '';

if ( isset( $instance['product_display'] ) ) {
	$number_of_product_display = $instance['product_display'];
}

$top_product_loop = new WP_Query( [
	'post_type'      => 'product',
	'meta_key'       => 'total_sales',
	'orderby'        => 'meta_value_num',
	'posts_per_page' => $number_of_product_display,
	'tax_query'      => [
		[
			'taxonomy' => 'product_cat',
			'field'    => 'slug',
			'terms'    => get_queried_object()->slug,
		]
	]
] );

if ( $top_product_loop->have_posts() ) {
	echo $args['before_widget']; ?>
	<h3><?php echo __( 'Bestverkochte ' ) . get_queried_object()->name; ?></h3>

	<ul>
		<?php while ( $top_product_loop->have_posts() ) : $top_product_loop->the_post(); ?>
			<li>
				<a href="<?php echo get_permalink(); ?>">
					<p><?php the_title(); ?></p>
					<figure><?php the_post_thumbnail( 'cat' ); ?></figure>
				</a>
			</li>
		<?php endwhile;
		wp_reset_postdata(); ?>
	</ul>
	<?php echo $args['after_widget'];
}