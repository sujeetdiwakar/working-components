<?php
/**
 * The template used for displaying slider content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
$offer = get_field( 'offer_text' );
if ( ( have_rows( 'slide_list' ) ) || ( have_rows( 'info_list' ) ) || ! empty( $offer ) ):?>
	<section class="hero">

		<?php if ( have_rows( 'slide_list' ) ): ?>
			<div class="hero__left js-content-slider">
				<?php while ( have_rows( 'slide_list' ) ): the_row();
					if ( ( $image = get_sub_field( 'slider_image' ) ) && ! empty( $image ) ):?>
						<figure>
							<?php if ( ( $url = get_sub_field( 'slide_url' ) ) && ! empty( $url ) ): ?>
								<a href="<?php echo $url; ?>">
									<?php echo wp_get_attachment_image( $image['id'], 'slider' ); ?>
								</a>
							<?php else: ?>
								<?php echo wp_get_attachment_image( $image['id'], 'slider' ); ?>
							<?php endif; ?>
						</figure>
					<?php endif;
				endwhile; ?>
			</div>
		<?php endif;

		if ( have_rows( 'info_list' ) ):?>
			<div class="hero__right">
				<?php
				while ( have_rows( 'info_list' ) ): the_row();
					$link  = get_sub_field( 'info_link' );
					$image = get_sub_field( 'info_image' );
					if ( ! empty( $link ) || ! empty( $link ) ):?>
						<a href="<?php echo $link['url']; ?>" target="<?php echo $link['target']; ?>">
							<?php echo wp_get_attachment_image( $image['id'], 'info' ); ?>
						</a>
					<?php endif;
				endwhile; ?>
			</div>
		<?php endif;

		if ( ! empty( $offer ) ):?>
			<footer>
				<p><?php echo $offer; ?></p>
			</footer>
		<?php endif; ?>
	</section>
<?php endif; ?>