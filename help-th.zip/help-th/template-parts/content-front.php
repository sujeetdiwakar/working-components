<?php
/**
 * The template used for displaying front page content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */

get_template_part( 'template-parts/content', 'hero' );
get_template_part( 'template-parts/content', 'featured' );
get_template_part( 'template-parts/content', 'popular' );
get_template_part( 'template-parts/content', 'usp' );
get_template_part( 'template-parts/content', 'ads' );
get_template_part( 'template-parts/content', 'range' );
get_template_part( 'template-parts/content', 'article' );