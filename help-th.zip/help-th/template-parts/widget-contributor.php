<?php
extract($args);
		extract($instance);
		echo $er_id;
?>

		<secction class="row profile-list">

			<secction class="col-xs-3">
				<img src="<?php echo get_avatar_url( $er_id ); ?>" alt="<?php  ?>">
				<?php 
				$user_info = get_userdata($er_id);
			
				echo $user_info->display_name; ?>
			</secction>

			

		</secction>

