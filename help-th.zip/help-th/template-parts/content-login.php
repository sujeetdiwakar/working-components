<?php
/**
 * The template used for displaying page content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
?>
<div class="content">
	<div class="content__login">
		<h1><?php _e( 'Inloggen' ); ?></h1>

		<?php the_content(); ?>
	</div>
</div>