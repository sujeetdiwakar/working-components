<?php
/**
 * The template used for displaying shipping content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */

if ( have_rows( 'shipping_info' ) ):?>
	<section class="usp">
		<?php while ( have_rows( 'shipping_info' ) ): the_row();
			$image   = get_sub_field( 'shipping_image' );
			$content = get_sub_field( 'shipping_content' );

			if ( ! empty( $image ) || ! empty( $content ) ):?>
				<aside>
					<?php if ( ! empty( $image ) ): ?>
						<figure>
							<?php echo wp_get_attachment_image( $image['id'], 'shipping' ); ?>
						</figure>
					<?php endif;
					echo $content;
					?>
				</aside>
			<?php endif;
		endwhile; ?>
	</section>
<?php endif; ?>