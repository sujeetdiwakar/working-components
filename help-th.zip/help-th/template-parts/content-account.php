<?php
/**
 * The template used for displaying account page content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */

$current_user = wp_get_current_user(); ?>

<div class="content">
	<div class="content__account">
		<h1><?php echo $current_user->display_name; ?></h1>

		<p><?php printf( __( 'E-mailadres : %1$s <a href="%2$s">Uitloggen</a>', 'woocommerce' ), '' . esc_html( $current_user->user_email ) . '', esc_url( wc_logout_url( wc_get_page_permalink( 'myaccount' ) ) ) ); ?></p>

		<?php the_content(); ?>
	</div>
</div>