<?php
/**
 * The template used for displaying post loop
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
?>
<div class="content__article__post">

	<h2><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>

	<p class="postmetadata"><?php the_time( 'F jS, Y' ) ?> by <?php the_author() ?></p>

	<figure><?php the_post_thumbnail( 'thumbnail' ); ?></figure>

	<div class="content">
		<?php the_excerpt(); ?>
	</div>

</div>