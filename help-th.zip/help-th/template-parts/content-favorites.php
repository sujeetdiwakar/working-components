<?php
/**
 * The template used for displaying favorites content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */


echo do_shortcode( '[yith_wcwl_wishlist]' ); ?>

