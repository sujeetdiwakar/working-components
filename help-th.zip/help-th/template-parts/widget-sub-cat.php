<?php

if ( is_tax( 'product_cat' ) ) {

	$title = ( $instance['title'] ) ? $instance['title'] : 'Sub Category';
	global $wp_query;

	$is_pro_cat_page = $wp_query->query_vars['product_cat'];

	if ( $is_pro_cat_page ) {

		$category      = get_term_by( 'name', $is_pro_cat_page, 'product_cat' );
		$category_id   = $category->term_id;
		$term_children = get_term_children( $category_id, 'product_cat' );
		if ( count( $term_children ) ) {
			$widget_content = '<ul class="pro_cats_list">';
			foreach ( $term_children as $term_child ) {
				$term = get_term_by( 'id', $term_child, 'product_cat' );

				$widget_content .= '<li><a href="' . get_term_link( $term->term_id ) . '" title="' . $term->name . '">' . $term->name . '</a></li>';
			}
			$widget_content .= '</ul>';
		} else {

			$parent        = get_queried_object()->parent;
			$category      = get_term_by( 'id', $parent, 'product_cat' );
			$category_id   = $category->term_id;
			$term_children = get_term_children( $category_id, 'product_cat' );
			if ( count( $term_children ) ) {
				$widget_content = '<ul class="pro_cats_list">';
				foreach ( $term_children as $term_child ) {
					$term = get_term_by( 'id', $term_child, 'product_cat' );

					$widget_content .= '<li><a href="' . get_term_link( $term->term_id ) . '" title="' . $term->name . '">' . $term->name . '</a></li>';
				}
				$widget_content .= '</ul>';
			}
		}

		echo $args['before_widget'] . $args['before_title'] . $title . $args['after_title'] . $widget_content . $args['after_widget'];
	}
}
?>