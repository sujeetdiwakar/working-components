<?php
/**
 * The template used for displaying range content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */

$section_title = get_field( 'range_section_title' );
$select_range  = get_field( 'select_range' );

if ( ! empty( $section_title ) || ! empty( $select_range ) ):?>
	<section class="range">

		<div class="range__item">
			<?php if ( ! empty( $section_title ) ): ?>
				<h3><?php echo $section_title; ?></h3>
			<?php endif;
			if ( ! empty( $select_range ) ):?>
				<ul>
					<?php foreach ( $select_range as $range ): ?>
						<li>
							<a href="<?php echo get_term_link( $range->term_id ); ?>">
								<?php
								$thumbnail_id = get_woocommerce_term_meta( $range->term_id, 'thumbnail_id', true );
								$image        = wp_get_attachment_url( $thumbnail_id );
								if ( ! empty( $image ) ): ?>
									<figure>
										<?php echo wp_get_attachment_image( $thumbnail_id, 'product-cat' ); ?>
									</figure>
								<?php endif ?>
								<strong><?php echo $range->name; ?></strong> </a>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

	</section>
<?php endif; ?>