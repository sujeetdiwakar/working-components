<?php
/**
 * The template used for displaying page content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
?>
<section class="article">
	<figure>
		<?php the_post_thumbnail( 'banner-home' ); ?>
	</figure>

	<article>
		<?php the_content(); ?>
	</article>
</section>
