<?php
/**
 * The template used for displaying product content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
global $woocommerce;
$product_cats = get_field( 'select_category' );
$product_ids  = get_field( 'select_product' );
if ( ! empty( $product_cats ) || ! empty( $product_ids ) ):?>
	<section class="featured">
		<?php if ( ! empty( $product_cats ) ): ?>
			<div class="featured__left">
				<ul>
					<?php foreach ( $product_cats as $product_cat ): ?>
						<li>
							<a href="<?php echo get_term_link( $product_cat->term_id ); ?>"><?php echo $product_cat->name; ?></a>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endif;

		if ( ! empty( $product_ids ) ):

			$args = [
				'post_type' => 'product',
				'post__in'  => $product_ids,
				'orderby'   => 'post__in',
			];

			$select_product = new WP_Query( $args );
			?>
			<div class="featured__right js-carousel-product">
				<?php
				while ( $select_product->have_posts() ): $select_product->the_post();
					$currency     = get_woocommerce_currency_symbol();
					$price        = get_post_meta( get_the_ID(), '_regular_price', true );
					$sale         = get_post_meta( get_the_ID(), '_sale_price', true );
					$stock_status = get_post_meta( get_the_ID(), '_stock_status', true );
					$rating       = get_post_meta( get_the_ID(), '_wc_average_rating', true );
					$product      = wc_get_product( get_the_ID() ); ?>
					<aside class="<?php echo ( $sale ) ? 'offer' : ''; ?>">
						<figure>
							<a href="<?php the_permalink(); ?>">
								<?php the_post_thumbnail( 'product' );
								if ( ! empty( $price ) && ! empty( $sale ) ):?>
									<div class="featured__tag">
										<?php $maximumper = 0;
										$percentage       = round( ( ( ( $price - $sale ) / $price ) * 100 ), 1 );
										if ( $percentage > $maximumper ) {
											$maximumper = $percentage;
										} ?>
										<strong><?php echo $maximumper . __( '% SALE' ); ?></strong>
									</div>
								<?php endif; ?>
							</a>
						</figure>

						<div class="featured__rating woocommerce">
							<?php echo wc_get_rating_html( $product->get_average_rating() ); ?>
						</div>

						<h4><?php the_title(); ?></h4>

						<div class="featured__price">
							<?php
							if ( $price == "" ) {
								$min_variation_price = $product->get_variation_regular_price( 'min' );
								$max_variation_price = $product->get_variation_regular_price( 'max' ); ?>
								<span><?php _e( 'v.a.' ); ?></span>
								<strong><?php echo $currency . " " . str_replace( '.', ',', $min_variation_price ); ?></strong>
								<?php
							} else {
								if ( ! empty( $price ) || ! empty( $sale ) ):
									if ( ! empty( $sale ) ):

										if ( ! empty( $price ) ): ?>
											<span><?php echo $currency . " " . str_replace( '.', ',', $price ); ?> </span>
										<?php endif;

										if ( ! empty( $sale ) ):?>
											<strong><?php echo $currency . " " . str_replace( '.', ',', $sale ); ?></strong>
										<?php endif;
									else:?>
										<span><?php _e( 'v.a.' ); ?></span>
										<strong><?php echo $currency . " " . str_replace( '.', ',', $price ); ?></strong>
									<?php
									endif;
								endif;
							}
							?>
						</div>

						<div class="featured__stock woocommerce">
							<?php if ( $stock_status !== 'instock' ) { // if stock is low
								echo '<p class="stock out-stock">' . __( 'Uitverkocht' ) . '</p>';
							} else {
								echo '<p class="stock in-stock">' . __( 'Op Voorraad' ) . '</p>';
							} ?>
						</div>

						<article>
							<?php the_excerpt(); ?>
						</article>

						<a href="<?php the_permalink(); ?>" class="button"><?php _e( 'Meer informatie' ); ?> ></a>
					</aside>
				<?php endwhile;
				wp_reset_postdata(); ?>
			</div>

		<?php endif; ?>
	</section>
<?php endif; ?>