<?php
/**
 * The template used for displaying page content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
?>
<div class="content<?php if ( is_active_sidebar( 'left_sidebar' ) ): ?> content--sidebar<?php endif; ?>">
	<?php if ( is_cart() || is_checkout() ): ?>
		<div class="content__shop">
			<h1><?php the_title(); ?></h1>
			<?php the_content(); ?>
		</div>
	<?php else: ?>
		<div class="content__article">
			<h1><?php the_title(); ?></h1>
			<?php the_content(); ?>
		</div>
	<?php endif; ?>

	<?php get_sidebar(); ?>
</div>