<?php
/**
 * The template used for displaying subscribe content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
?>

<h2><?php _e( 'Nieuwsbrief abonnement' ); ?></h2>

<p><?php _e('Blijf op de hoogte en ontvang het laatste updates, acties/kortingen en nieuwe producten.'); ?></p>

<?php echo do_shortcode('[mc4wp_form id="124"]'); ?>