<?php
/**
 * The template used for displaying breadcrumbs
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */

if ( function_exists( 'yoast_breadcrumb' ) ) {
	yoast_breadcrumb( '<section class="breadcrumbs">', '</section>' );
}
