<?php
/**
 * The template used for displaying item content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
$supplements     = get_field( 'supplements_image' );
$supplements_ids = get_field( 'supplements' );
$sportswear      = get_field( 'sportswear_image' );
$sportswear_ids  = get_field( 'sportswear' );

if ( ! empty( $supplements ) || ! empty( $supplements_ids ) || ! empty( $sportswear ) || ! empty( $sportswear_ids ) ): ?>
	<section class="popular">
		<?php if ( ! empty( $supplements ) || ! empty( $sportswear_ids ) ): ?>
			<article>
				<?php if ( ! empty( $supplements ) ):
					echo wp_get_attachment_image( $supplements['id'], 'selling-label' );
				endif;
				$args             = [
					'post_type' => 'product',
					'post__in'  => $supplements_ids,
					'orderby'   => 'post__in',
				];
				$supplement_query = new WP_Query( $args );
				$i                = 1;
				while ( $supplement_query->have_posts() ): $supplement_query->the_post();
					$currency     = get_woocommerce_currency_symbol();
					$price        = get_post_meta( get_the_ID(), '_regular_price', true );
					$sale         = get_post_meta( get_the_ID(), '_sale_price', true );
					$stock_status = get_post_meta( get_the_ID(), '_stock_status', true );
					$product      = wc_get_product( get_the_ID() ); ?>
					<aside>
						<div class="popular__number">
							<?php echo $i; ?>
						</div>

						<figure>
							<a href="<?php the_permalink(); ?>">
								<?php the_post_thumbnail( 'selling' ); ?>
							</a>
						</figure>

						<div class="popular__detail">

							<h3><?php the_title(); ?></h3>

							<div class="popular__stock woocommerce">
								<?php if ( $stock_status !== 'instock' ) { // if stock is low
									echo '<p class="stock out-stock">' . __( 'Uitverkocht' ) . '</p>';
								} else {
									echo '<p class="stock in-stock">' . __( 'Op Voorraad' ) . '</p>';
								} ?>
							</div>

							<?php the_excerpt(); ?>

						</div>

						<div class="popular__rate">
							<div class="popular__rating woocommerce">
								<?php echo wc_get_rating_html( $product->get_average_rating() ); ?>
							</div>

							<div class="popular__price">
								<?php
								if ( $price == "" ) {
									$min_variation_price = $product->get_variation_regular_price( 'min' );
									$max_variation_price = $product->get_variation_regular_price( 'max' ); ?>
									<span><?php _e( 'v.a.' ); ?></span>
									<strong><?php echo $currency . " " . str_replace( '.', ',', $min_variation_price ); ?></strong>
									<?php
								} else {
									if ( ! empty( $price ) || ! empty( $sale ) ):
										if ( ! empty( $sale ) ):

											if ( ! empty( $price ) ): ?>
												<span><?php echo $currency . " " . str_replace( '.', ',', $price ); ?> </span>
											<?php endif;

											if ( ! empty( $sale ) ):?>
												<strong><?php echo $currency . " " . str_replace( '.', ',', $sale ); ?></strong>
											<?php endif;
										else:?>
											<span><?php _e( 'v.a.' ); ?></span>
											<strong><?php echo $currency . " " . str_replace( '.', ',', $price ); ?></strong>
										<?php
										endif;
									endif;
								}
								?>
							</div>
							<a href="<?php the_permalink(); ?>" class="button"><?php _e( 'Bestel nu' ); ?> ></a>
						</div>
					</aside>
					<?php
					$i ++;
				endwhile;
				wp_reset_postdata(); ?>
			</article>
		<?php endif;

		if ( ! empty( $sportswear ) || ! empty( $sportswear_ids ) ):?>
			<article>
				<?php if ( ! empty( $sportswear ) ):
					echo wp_get_attachment_image( $sportswear['id'], 'selling-label' );
				endif;
				$args             = [
					'post_type' => 'product',
					'post__in'  => $sportswear_ids,
					'orderby'   => 'post__in',
				];
				$sportswear_query = new WP_Query( $args );
				$i                = 1;
				while ( $sportswear_query->have_posts() ): $sportswear_query->the_post();
					$currency     = get_woocommerce_currency_symbol();
					$price        = get_post_meta( get_the_ID(), '_regular_price', true );
					$sale         = get_post_meta( get_the_ID(), '_sale_price', true );
					$stock_status = get_post_meta( get_the_ID(), '_stock_status', true );
					$product      = wc_get_product( get_the_ID() );
					?>
					<aside>
						<div class="popular__number">
							<?php echo $i; ?>
						</div>

						<figure>
							<a href="<?php the_permalink(); ?>">
								<?php the_post_thumbnail( 'selling' ); ?>
							</a>
						</figure>

						<div class="popular__detail">

							<h3><?php the_title(); ?></h3>

							<div class="popular__stock woocommerce">
								<?php if ( $stock_status !== 'instock' ) { // if stock is low
									echo '<p class="stock out-stock">' . __( 'Uitverkocht' ) . '</p>';
								} else {
									echo '<p class="stock in-stock">' . __( 'Op Voorraad' ) . '</p>';
								} ?>
							</div>

							<?php the_excerpt(); ?>

						</div>

						<div class="popular__rate">
							<div class="popular__rating woocommerce">
								<?php echo wc_get_rating_html( $product->get_average_rating() ); ?>
							</div>

							<div class="popular__price">
								<?php
								if ( $price == "" ) {
									$min_variation_price = $product->get_variation_regular_price( 'min' );
									$max_variation_price = $product->get_variation_regular_price( 'max' ); ?>
									<span><?php _e( 'v.a.' ); ?></span>
									<strong><?php echo $currency . " " . str_replace( '.', ',', $min_variation_price ); ?></strong>
									<?php
								} else {
									if ( ! empty( $price ) || ! empty( $sale ) ):
										if ( ! empty( $sale ) ):

											if ( ! empty( $price ) ): ?>
												<span><?php echo $currency . " " . str_replace( '.', ',', $price ); ?> </span>
											<?php endif;

											if ( ! empty( $sale ) ):?>
												<strong><?php echo $currency . " " . str_replace( '.', ',', $sale ); ?></strong>
											<?php endif;
										else:?>
											<span><?php _e( 'v.a.' ); ?></span>
											<strong><?php echo $currency . " " . str_replace( '.', ',', $price ); ?></strong>
										<?php
										endif;
									endif;
								}
								?>
							</div>
							<a href="<?php the_permalink(); ?>" class="button"><?php _e( 'Bestel nu' ); ?> ></a>
						</div>
					</aside>
					<?php
					$i ++;
				endwhile;
				wp_reset_postdata(); ?>
			</article>
		<?php endif; ?>
	</section>
<?php endif; ?>