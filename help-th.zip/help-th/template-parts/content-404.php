<?php
/**
 * The template used for displaying 404 content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */
?>
<article class="content<?php if ( is_active_sidebar( 'right_sidebar' ) ): ?> content--sidebar<?php endif; ?>">
	<div class="content__article">
		<h1>Error 404 Not Found</h1>
		<h3>Oops. Fail. The page cannot be found.</h3>
		<p>:(</p>
	</div>
</article>