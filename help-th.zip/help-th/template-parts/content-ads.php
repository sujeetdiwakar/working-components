<?php
/**
 * The template used for displaying top article content
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      3.4.6
 * @version    3.4.6
 */

if ( have_rows( 'top_article' ) ):?>
	<section class="ads">
		<?php while ( have_rows( 'top_article' ) ): the_row();
			$image = get_sub_field( 'article_image' );
			$link  = get_sub_field( 'article_link' );

			if ( ! empty( $link ) || ! empty( $image ) ):?>
				<a href="<?php echo $link['url']; ?>" target="<?php echo $link['target']; ?>">
					<?php echo wp_get_attachment_image( $image['id'], 'top-article' ); ?>
				</a>
			<?php endif;
		endwhile; ?>
	</section>
<?php endif; ?>