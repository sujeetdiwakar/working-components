<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      1.0
 * @version    1.0
 */

get_header(); ?>
	<main role="main" class="container">
		<?php while ( have_posts() ) {
			the_post();

			if ( is_front_page() ) {
				get_template_part( 'template-parts/content', 'front' );
			} elseif ( is_account_page() && ! is_user_logged_in() ) {
				get_template_part( 'template-parts/content', 'login' );
			} elseif ( is_account_page() && is_user_logged_in() ) {
				get_template_part( 'template-parts/content', 'account' );
			} else {
				get_template_part( 'template-parts/content', 'page' );
			}
		} ?>
	</main>
<?php get_footer();

