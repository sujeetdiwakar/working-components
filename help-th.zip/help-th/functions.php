<?php
/**
 * Theme functions and definitions
 *
 * Set up the theme and initiates the autoloader containing some helper
 * functions, which are used in the theme as custom template tags.
 * Others are attached to action and filter hooks in WordPress to change
 * core functionality.
 *
 * @link       https://codex.wordpress.org/Theme_Development
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 *
 * @link       https://codex.wordpress.org/Plugin_API
 *
 * More information about the theme classes and functions can be found by generating
 * the documentation using:
 *
 * apigen generate --source="./" --destination="docs" --deprecated --exclude="_additional"
 * --internal --php --template-theme="bootstrap" --title="Custom_Theme" --todo --tree
 *
 * @link       http://www.apigen.org
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      1.0
 * @version    1.0
 */

// include js in the my_theme-Theme
function my_theme_theme_scripts() {
	if ( ! is_admin() ) {

		// load a JS file from my_theme-Theme
		wp_enqueue_script( 'jquery' );
		wp_enqueue_script( 'vendor-js', get_bloginfo( 'template_url' ) . '/js/vendor.min.js', [ 'jquery' ], '1.0.0', true );
		wp_enqueue_script( 'script-js', get_bloginfo( 'template_url' ) . '/js/script.min.js', [ 'jquery' ], '1.0.0', true );

		// load a CSS file from my_theme-Theme
		wp_enqueue_style( 'style-css', get_bloginfo( 'template_url' ) . '/css/style.min.css' );
	}
}

add_action( 'wp_enqueue_scripts', 'my_theme_theme_scripts' );

// side bar option start here
if ( function_exists( 'register_sidebar' ) ) {
	register_sidebar( [
		'name'          => 'Left Sidebar',
		'id'            => 'left_sidebar',
		'description'   => 'This area for Default Left Sidebar',
		'before_widget' => '<aside class="%2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	] );
	register_sidebar( [
		'name'          => 'Footer 1',
		'id'            => 'footer_1',
		'description'   => 'This area for Footer 1',
		'before_widget' => '<div class="%2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	] );
	register_sidebar( [
		'name'          => 'Footer 2',
		'id'            => 'footer_2',
		'description'   => 'This area for Footer 2',
		'before_widget' => '<div class="%2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	] );
	register_sidebar( [
		'name'          => 'Footer 3',
		'id'            => 'footer_3',
		'description'   => 'This area for Footer 3',
		'before_widget' => '<div class="%2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	] );
	register_sidebar( [
		'name'          => 'Footer 4',
		'id'            => 'footer_4',
		'description'   => 'This area for Footer 4',
		'before_widget' => '<div class="%2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	] );
}
// side bar option end here

// enable post thumbnail option start here
add_theme_support( 'post-thumbnails' );

// enable image cropping sizes start here
function my_theme_image_theme_setup() {
	add_image_size( 'product-cat', 120, 120 );
	add_image_size( 'product', 130, 173 );
	add_image_size( 'selling', 112, 136 );
	add_image_size( 'shipping', 99, 99 );
	add_image_size( 'post-image', 320, 260, true );
	add_image_size( 'slider', 734, 312, true );
	add_image_size( 'info', 466, 156, true );
	add_image_size( 'selling-label', 600, 139, true );
	add_image_size( 'banner-img', 950, 275, true );
	add_image_size( 'top-article', 400, 156, true );
	add_image_size( 'banner-home', 1200, 273, true );
}

add_action( 'after_setup_theme', 'my_theme_image_theme_setup' );

// assign custom thumbnail size start here
if ( has_post_thumbnail() ) {
	the_post_thumbnail( 'post-image' );
}

// assign media library images start here
add_filter( 'image_size_names_choose', 'my_theme_image_custom_sizes' );

function my_theme_image_custom_sizes( $sizes ) {
	return array_merge( $sizes, [
		'post-image' => __( 'Post Image' ),
	] );
}

// wp nav menu option start here
function register_my_menus() {
	register_nav_menus(
		[
			'primary' => 'Primary Navigation',
		]
	);
}

add_action( 'init', 'register_my_menus' );
// wp nav menu option end here

// custom excerpt length
function custom_excerpt_length( $length ) {
	return 65;
}

add_filter( 'excerpt_length', 'custom_excerpt_length' );

// Define additional option pages
if ( function_exists( 'acf_add_options_page' ) ) {

	$options = acf_add_options_page( [
		'page_title' => 'Theme options',
		'menu_title' => 'Theme options',
		'menu_slug'  => 'options-theme',
		'capability' => 'edit_posts',
		'redirect'   => false
	] );
}

// woocommerce theme support
add_action( 'woocommerce_before_shop_loop', 'woocommerce_pagination', 40 );
add_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 30 );
add_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 20 );
add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_price', 8 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 25 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 30 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 50 );
add_action( 'woocommerce_single_product_summary', 'my_theme_display_product_info', 55 );
add_action( 'woocommerce_single_product_summary', 'my_theme_show_stock_shop', 51 );

add_filter( 'woocommerce_show_page_title', '__return_false' );
add_filter( 'woocommerce_get_stock_html', '__return_empty_string' );
add_filter( 'wc_product_sku_enabled', '__return_false' );

remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50 );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );

add_action( 'after_setup_theme', 'my_theme_add_woocommerce_support' );
function my_theme_add_woocommerce_support() {
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
}

add_action( 'woocommerce_before_main_content', 'my_theme_theme_main_start', 5 );
function my_theme_theme_main_start() {
	echo '<main role="main" class="container">';
}

add_action( 'woocommerce_before_main_content', 'my_theme_display_breadcrumbs', 8 );
function my_theme_display_breadcrumbs() {
	get_template_part( 'template-parts/content', 'breadcrumbs' );
}

add_action( 'woocommerce_before_main_content', 'my_theme_theme_content_start', 10 );
function my_theme_theme_content_start() {
	echo '<section class="content">';
}

add_action( 'woocommerce_before_main_content', 'my_theme_theme_shop_start', 15 );
function my_theme_theme_shop_start() {
	if ( is_active_sidebar( 'left_sidebar' ) ) {
		echo '<div class="content__shop content__shop-sidebar">';
	} else {
		echo '<div class="content__shop">';
	}
}

add_action( 'woocommerce_after_main_content', 'my_theme_theme_shop_end', 5 );
function my_theme_theme_shop_end() {
	echo '</div>';
}

add_action( 'woocommerce_after_main_content', 'my_theme_theme_content_end', 10 );
function my_theme_theme_content_end() {
	echo '</section>';
}

add_action( 'woocommerce_after_main_content', 'my_theme_theme_sidebar_end', 8 );
function my_theme_theme_sidebar_end() {
	get_sidebar();
}

add_action( 'woocommerce_after_main_content', 'my_theme_theme_main_end', 15 );
function my_theme_theme_main_end() {
	echo '</main>';
}

add_action( 'woocommerce_before_shop_loop', 'my_theme_product_filter_start', 15 );
function my_theme_product_filter_start() {
	echo '<div class="woocommerce-filter">';
}

add_action( 'woocommerce_before_shop_loop', 'my_theme_product_filter_end', 50 );
function my_theme_product_filter_end() {
	echo '</div>';
}

add_action( 'woocommerce_before_shop_loop_item_title', 'my_theme_loop_thumb_figure_start', 5 );
function my_theme_loop_thumb_figure_start() {
	echo '<figure><a href="' . get_permalink() . '">';
}

add_action( 'woocommerce_before_shop_loop_item_title', 'my_theme_loop_thumb_figure_end', 15 );
function my_theme_loop_thumb_figure_end() {
	$price      = get_post_meta( get_the_ID(), '_regular_price', true );
	$sale       = get_post_meta( get_the_ID(), '_sale_price', true );
	$maximumper = 0;
	@$percentage = round( ( ( ( $price - $sale ) / $price ) * 100 ), 1 );
	if ( $percentage > $maximumper ) {
		$maximumper = $percentage;
	}
	if ( ! empty( $price ) && ! empty( $sale ) ) {
		echo '<div class="featured__tag"><strong>' . $maximumper . '% SALE</strong></div>';
	}
	echo '</a></figure>';
}

add_action( 'woocommerce_product_thumbnails', 'my_theme_sale_percentage_action', 5 );

function my_theme_sale_percentage_action() {
	$price      = get_post_meta( get_the_ID(), '_regular_price', true );
	$sale       = get_post_meta( get_the_ID(), '_sale_price', true );
	$maximumper = 0;
	$percentage = round( ( ( ( $price - $sale ) / $price ) * 100 ), 1 );
	if ( $percentage > $maximumper ) {
		$maximumper = $percentage;
	}
	if ( ! empty( $price ) && ! empty( $sale ) ) {
		echo '<div class="featured__tag"><strong>' . $maximumper . '% SALE</strong></div>';
	}
}

add_action( 'woocommerce_shop_loop_item_title', 'my_theme_loop_article_start', 5 );
function my_theme_loop_article_start() {
	echo '<article>';
}

add_action( 'woocommerce_after_shop_loop_item_title', 'my_theme_loop_article_end', 20 );
function my_theme_loop_article_end() {

	echo '<a href="' . get_permalink() . '" class="button button--dark button--arrow">' . __( 'Meer informatie' ) . '</a> </article>';
}

add_action( 'woocommerce_after_shop_loop_item', 'my_theme_loop_aside_start', 5 );
function my_theme_loop_aside_start() {
	echo '<aside>';
}

add_action( 'woocommerce_after_shop_loop_item', 'my_theme_loop_aside_end', 25 );
function my_theme_loop_aside_end() {
	echo '</aside>';
}

add_action( 'woocommerce_after_shop_loop_item_title', 'my_theme_loop_pro_excerpt', 15 );
function my_theme_loop_pro_excerpt() {
	the_excerpt();
}

add_action( 'woocommerce_single_product_summary', 'my_theme_product_summery_left_start', 1 );
function my_theme_product_summery_left_start() {
	echo '<div class="summer-left">';
}

add_action( 'woocommerce_single_product_summary', 'my_theme_product_summery_left_end', 35 );
function my_theme_product_summery_left_end() {
	echo '</div>';
}

add_action( 'woocommerce_single_product_summary', 'my_theme_product_summery_right_start', 40 );
function my_theme_product_summery_right_start() {
	echo '<div class="summer-right">';
}

add_action( 'woocommerce_single_product_summary', 'my_theme_product_summery_right_end', 70 );
function my_theme_product_summery_right_end() {
	echo '</div>';
}

add_action( 'woocommerce_single_product_summary', 'my_theme_product_social_share', 30 );
function my_theme_product_social_share() {
	echo do_shortcode( '[ssba-buttons]' );
}

add_action( 'woocommerce_single_product_summary', 'my_theme_hide_variable_product_price' );
function my_theme_hide_variable_product_price() {
	global $product;

	if ( $product->is_type( 'variable' ) ) {
		add_action( 'woocommerce_before_add_to_cart_button', 'woocommerce_template_single_price', 10 );
	} else {
		add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 45 );
	}
}

add_action( 'woocommerce_archive_description', 'my_theme_woo_category_banner', 15 );
function my_theme_woo_category_banner() {
	$term = get_queried_object();
	if ( ( $banner = get_field( 'banner_image', $term ) ) && ! empty( $banner ) ) {
		echo '<figure>' . wp_get_attachment_image( $banner['id'], 'banner-img' ) . '</figure>';
	}
}

add_filter( 'woocommerce_catalog_orderby', 'my_theme_woocommerce_catalog_orderby', 20 );
function my_theme_woocommerce_catalog_orderby( $orderby ) {
	$orderby['popularity'] = __( 'Relevantie', 'woocommerce' );
	$orderby['rating']     = __( 'Bestverkochte', 'woocommerce' );
	$orderby['date']       = __( 'Nieuwste', 'woocommerce' );
	$orderby['price']      = __( 'Lage prijs', 'woocommerce' );
	$orderby['price-desc'] = __( 'Hoge prijs', 'woocommerce' );

	return $orderby;
}

add_filter( 'woocommerce_get_catalog_ordering_args', 'wcs_get_catalog_ordering_args' );
function wcs_get_catalog_ordering_args( $args ) {

	$orderby_value = isset( $_GET['orderby'] ) ? woocommerce_clean( $_GET['orderby'] ) : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby' ) );
	if ( 'on_sale' == $orderby_value ) {

		$args['orderby']  = 'meta_value_num';
		$args['order']    = 'DESC';
		$args['meta_key'] = '_sale_price';
	}

	return $args;
}

add_filter( 'woocommerce_default_catalog_orderby_options', 'wcs_catalog_orderby' );

add_filter( 'woocommerce_catalog_orderby', 'wcs_catalog_orderby' );
function wcs_catalog_orderby( $sortby ) {

	$sortby['on_sale'] = 'Sale';

	return $sortby;
}

add_filter( 'wppp_ppp_text', 'wppp_custom_text', 10, 2 );
function wppp_custom_text( $text, $value ) {
	if ( $value == '-1' ) {
		return 'All';
	}

	return '%s';
}

add_action( 'woocommerce_after_shop_loop_item', 'my_theme_show_stock_shop', 15 );
function my_theme_show_stock_shop() {
	global $product;
	if ( $product->stock ) {
		if ( number_format( $product->stock, 0, '', '' ) < 3 ) { // if stock is low
			echo '<p class="stock out-stock">' . __( 'Uitverkocht' ) . '</p>';
		} else {
			echo '<p class="stock in-stock">' . __( 'Op Voorraad' ) . '</p>';
		}
	}
}

add_action( 'woocommerce_after_shop_loop_item_title', 'my_theme_show_rating_count', '5' );
function my_theme_show_rating_count() {
	global $product;
	$rating_count = $product->get_rating_count();
	$review_count = $product->get_review_count();
	$average      = $product->get_average_rating(); ?>
	<div class="woocommerce-product-rating">
		<?php echo wc_get_rating_html( $average, $rating_count ); ?>

		<a href="<?php echo get_permalink() ?>#reviews" rel="nofollow">
			<?php printf( _n( '%s', $review_count, 'woocommerce' ), '<span class="count"> ' . esc_html( $review_count ) . ' </span> ' );
			if ( $rating_count == 1 ) {
				_e( ' review' );
			} else {
				_e( ' reviews' );
			} ?>
		</a>

		<?php echo do_shortcode( '[yith_wcwl_add_to_wishlist]' ); ?>
	</div>
<?php }

add_action( 'woocommerce_single_product_summary', 'my_theme_show_wishlist', 10 );
function my_theme_show_wishlist() {
	global $product;
	$rating_count = $product->get_rating_count();
	$review_count = $product->get_review_count();
	$average      = $product->get_average_rating();

	if ( $rating_count >= 0 ) : ?>

		<?php if ( comments_open() ): ?>
			<div class="woocommerce-product-rating">
			<?php echo wc_get_rating_html( $average, $rating_count ); ?>
		<a href="<?php echo get_permalink() ?>#reviews" class="woocommerce-review-link" rel="nofollow">
			<?php printf( _n( '%s', $review_count, 'woocommerce' ), '<span class="count"> ' . esc_html( $review_count ) . ' </span> ' );
			echo " ";

			if ( $rating_count == 1 ) {
				_e( 'review' );
			} else {
				_e( 'reviews' );
			}

			?>
			</a><?php endif;
		echo do_shortcode( '[yith_wcwl_add_to_wishlist]' );
		?>
		</div>
	<?php endif;
}

add_action( 'woocommerce_after_shop_loop_item', 'my_theme_display_product_info', 20 );
function my_theme_display_product_info() {
	get_template_part( 'template-parts/content', 'info' );
}

/*** Remove product data tabs */
add_filter( 'woocommerce_product_tabs', 'my_theme_remove_product_tabs', 98 );
function my_theme_remove_product_tabs( $tabs ) {

	unset( $tabs['additional_information'] );

	return $tabs;
}

/*** Rename product data tabs */
add_filter( 'woocommerce_product_tabs', 'my_theme_rename_tabs', 98 );
function my_theme_rename_tabs( $tabs ) {

	$tabs['description']['title'] = __( 'Productinformatie' );
	$tabs['reviews']['title']     = __( 'Klantreviews' );

	return $tabs;
}

/*** Add composition product data tab */
add_filter( 'woocommerce_product_tabs', 'my_theme_product_composition_tab' );
function my_theme_product_composition_tab( $tabs ) {

	$tabs['composition_tab'] = [
		'title'    => __( 'Samenstelling', 'woocommerce' ),
		'priority' => 10,
		'callback' => 'woo_product_composition_content'
	];

	return $tabs;
}

function woo_product_composition_content() {

	echo '<h2>' . __( 'Samenstelling' ) . '</h2>';
	echo get_field( 'composition_content' );
}

/*** Add uses product data tab */
add_filter( 'woocommerce_product_tabs', 'my_theme_product_uses_tab' );
function my_theme_product_uses_tab( $tabs ) {

	$tabs['uses_tab'] = [
		'title'    => __( 'Gebruik', 'woocommerce' ),
		'priority' => 15,
		'callback' => 'woo_product_uses_content'
	];

	return $tabs;
}

function woo_product_uses_content() {

	echo '<h2>' . __( 'Gebruik' ) . '</h2>';
	echo get_field( 'uses_content' );
}

/*** Edit my account menu order */
function my_account_menu_order() {
	$menuOrder = [
		'dashboard'     => __( 'Dashboard', 'woocommerce' ),
		'orders'        => __( 'Mijn bestellingen', 'woocommerce' ),
		'edit-account'  => __( 'Accountinformatie', 'woocommerce' ),
		'edit-address'  => __( 'Adresboek', 'woocommerce' ),
		'contributions' => __( 'Mijn reviews', 'woocommerce' ),
		'favorites'     => __( 'Mijn favorietenlijst', 'woocommerce' ),
		'subscribe'     => __( 'Nieuwsbrief', 'woocommerce' ),
	];

	return $menuOrder;
}

add_filter( 'woocommerce_account_menu_items', 'my_account_menu_order' );

/*** Register new endpoints to use inside My Account page. */
add_action( 'init', 'my_account_favorites_endpoints' );
function my_account_favorites_endpoints() {
	add_rewrite_endpoint( 'favorites', EP_ROOT | EP_PAGES );
}

add_action( 'init', 'my_account_subscribe_endpoints' );
function my_account_subscribe_endpoints() {
	add_rewrite_endpoint( 'subscribe', EP_ROOT | EP_PAGES );
}

/*** Get new endpoint content */
// Favorites
add_action( 'woocommerce_account_favorites_endpoint', 'favorites_endpoint_content' );
function favorites_endpoint_content() {
	get_template_part( 'template-parts/content', 'favorites' );
}

// Subscribe
add_action( 'woocommerce_account_subscribe_endpoint', 'subscribe_endpoint_content' );
function subscribe_endpoint_content() {
	get_template_part( 'template-parts/content', 'subscribe' );
}

remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
add_action( 'woocommerce_shop_loop_item_title', 'my_theme_shop_loop_title_link', 10 );
function my_theme_shop_loop_title_link() {
	echo '<h2 class="woocommerce-loop-product__title"><a href=""' . get_the_permalink() . '> ' . get_the_title() . '</a></h2>';
}

class Product_subcategory extends WP_Widget {

	Public function __construct() {
		parent::__construct( 'Product_subcategory', 'Dueamici Product Sub Catyegory', [
			'classname'   => 'widget_categories',
			'description' => 'Dueamici Product Sub Catyegory',

		] );
	}

	function form( $instance ) {

		$title = $instance['title'];
		?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">Title:
				<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo $title; ?>">

			</label>
		</p>

		<?php

	}

	function widget( $args, $instance ) {
		require( locate_template( 'template-parts/widget-' . 'sub-cat.php' ) );
	}

}

class Best_selling_products_Widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'best_selling_product_widget', // Base ID
			esc_html__( 'Best Selling Products', 'best_selling_product' ), // Name
			[ 'description' => esc_html__( 'Best Selling Products from a current product category', 'best_selling_product' ), ] // Args
		);
	}

	public function widget( $args, $instance ) {
		require( locate_template( 'template-parts/widget-' . 'best-selling.php' ) );
	}

	public function form( $instance ) {
		$product_display = ! empty( $instance['product_display'] ) ? $instance['product_display'] : esc_html__( '3', 'best_selling_product' ); ?>
		<p>
			<label>
				<?php _e( 'No Of Product to Display :' ); ?>
				<input type='text' id="<?php echo esc_attr( $this->get_field_id( 'product_display' ) ); ?>" name='<?php echo esc_attr( $this->get_field_name( 'product_display' ) ); ?>' value="<?php echo esc_attr( $product_display ); ?>" />
			</label>
		</p>

	<?php }

	public function update( $new_instance, $old_instance ) {
		$instance                    = [];
		$instance['product_display'] = ( ! empty( $new_instance['product_display'] ) ) ? strip_tags( $new_instance['product_display'] ) : '';

		return $instance;
	}

}


// use widgets_init action hook to execute custom function


//boj_widget_my_info class
class jm_box_widget_my_info extends WP_Widget {

    //process the new widget
    function jm_box_widget_my_info() {
        $widget_ops = array( 
            'classname' => 'jm_box_widget_class', 
            'description' => 'Sidebar Box Widget.'
            ); 
        $this->WP_Widget( 'jm_box_widget_my_info', 'Box Widget', $widget_ops );
    }

     //build the widget settings form
    function form($instance) {
        $defaults = array( 'title' => 'Box Page Widget', 'description' => '', 'boxtype' => '' ); 
        $instance = wp_parse_args( (array) $instance, $defaults );
        $title = $instance['title'];
        $description = $instance['description'];
        $boxtype = $instance['boxtype'];

        ?>
            <p>Title: <input class="widefat" name="<?php echo $this->get_field_name( 'title' ); ?>"  type="text" value="<?php echo esc_attr( $title ); ?>" /></p>
            <p>Description: <textarea class="widefat" name="<?php echo $this->get_field_name( 'description' ); ?>" / ><?php echo esc_attr( $description ); ?></textarea></p>
    <p>Sex:
            <select id="<?php echo $this->get_field_id( 'boxtype' ); ?>" name="<?php echo $this->get_field_name( 'boxtype' ); ?>" class="widefat" style="width:100%;">
            <option <?php if ( 'box1' ==  $instance['boxtype'] ) echo 'selected="selected"'; ?> value="box1">box1</option>
    <option <?php if ( 'box2' ==  $instance['boxtype'] ) echo 'selected="selected"'; ?> value="box2">box2</option>
            </select>
        </p>
        <?php
    }

    //save the widget settings
    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['description'] = strip_tags( $new_instance['description'] );
        $instance['boxtype'] = ( $new_instance['boxtype'] ); 
        return $instance;
    }

    //display the widget
    function widget($args, $instance) {
        extract($args);

        echo $before_widget;
        $title = apply_filters( 'widget_title', $instance['title'] );
        $description = empty( $instance['description'] ) ? '&nbsp;' : $instance['description']; 
        echo "boxtyp".$boxtype = empty( $instance['boxtype'] ) ? '&nbsp;' : $instance['boxtype']; 

        echo '<div class="sidebar-box" id="' . $boxtype . '" onmouseover="this.style.cursor=\'pointer\'" onmouseup="window.location=\'' . $boxtype . '\'">
                <h3>' . $title . '</h3>
                <p>' . $description . '</p>
                </div>';
        echo $after_widget;
    }
}


class Contributor_Widget extends WP_Widget {

	function __construct() {
		parent::__construct(
			'contributor_widget',
			esc_html__( 'Contributor Widget', 'contributor_widget' ),
			[ 'description' => esc_html__( 'Contributor Widget', 'contributor_widget' ), ]
		);
	}

	public function widget( $args, $instance ) {
		$widget_id = 'widget_' . $args['widget_id'];
		require( locate_template( 'template-parts/widget-' . 'contributor.php' ) );
	}

	public function form( $instance ) {
		$title_field_name = 'title';
		
		$er_id=$instance["er_id"];
		
		$editor_id=$this->get_field_name("er_id");
		
		$argss = [
				'role' => 'Editor',
				'orderby' => 'post_count',
				'order'   => 'DESC',
				'number'  => 3

			];

		$wp_user_q = new WP_User_Query( $argss );
		//print_r($wp_user_q->results);
		?>

		<select id="<?php echo $this->get_field_id( 'er_id' ); ?>" name="<?php echo $this->get_field_name( 'er_id' ); ?>">
			<?php 
			if($wp_user_q->results):
			echo "<option value=''>Select Editor</option>";
			foreach ( $wp_user_q->results as $u ): ?>
            <option value='<?php echo $u->ID; ?>' <?php echo( $u->ID ==  $er_id )?'selected':''; ?>>
				<?php echo $u->display_name; ?>
			</option>
			<?php endforeach; endif; ?>
            </select>
			<?php
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance["er_id"]=$new_instance["er_id"];
		
		
		//Return back to the environment
		return $instance;
	}
}
//template part




function dueamici_wc_register_widget_() {
	register_widget( 'Product_subcategory' );
	register_widget( 'Best_selling_products_Widget' );
	register_widget( 'jm_box_widget_my_info' );
	register_widget( 'Contributor_Widget' );
}

add_action( 'widgets_init', 'dueamici_wc_register_widget_' );