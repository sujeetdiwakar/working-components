<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      1.0
 * @version    1.0
 */

get_header(); ?>
	<main role="main" class="container">
		<?php get_template_part( 'template-parts/content', '404' ); ?>
		<?php get_sidebar(); ?>
	</main>
<?php get_footer();