<?php
/**
 * Template Name: Home Page
 */

get_header(); ?>
<?php get_template_part( 'template-parts/content', 'banner' ); ?>
<?php get_template_part( 'template-parts/content', 'front' ); ?>
<?php get_footer();
