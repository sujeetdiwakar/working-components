<?php
/**
 * The template for displaying search results pages
 *
 * @package    WordPress
 * @subpackage Custom_Theme
 * @since      1.0
 * @version    1.0
 */

get_header(); ?>
<main role="main" class="container">
	<h1>Search Results</h1>

	<?php
	// Start the loop.
	while ( have_posts() ) {
		the_post();

		// Include the single post content template.
		get_template_part( 'template-parts/content', 'post' );
	}

	get_sidebar(); ?>
</main>
<?php get_footer(); ?>
