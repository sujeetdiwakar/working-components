jQuery(document).ready(function( $ ) {
	$('.images a').on('click',function(e){
		e.preventDefault();
		alert('click');

	});
});
